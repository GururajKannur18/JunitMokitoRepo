package com.capgemini.payroll.client;
public class MainClass {
	public static void main(String[] args){
	}
}